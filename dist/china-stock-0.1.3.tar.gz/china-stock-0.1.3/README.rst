china-stock
===========

~~~~~~~
Install
~~~~~~~

.. code:: bash

	$ pip install china-stock

~~~
Use
~~~

.. code:: python

	>>> import chinastock as cs

	>>> cs.get_stock_today('000001','SZ')